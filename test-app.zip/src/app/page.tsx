import { SlideTabs } from "./section/SlideTabs";
import { ChipTabs } from "@/app/section/ChipTabs";
import { Hero } from "@/app/section/Hero";
import { Skills } from "./section/Skills";
import { SliderExample } from "@/app/section/SliderExample";
export default function Home() {
  return (
    <div>
      {/* <SlideTabs /> */}
      <Skills />
      {/* <SliderExample/> */}
      {/* <Hero /> */}
      {/* <ChipTabs /> */}
    </div>
  );
}
