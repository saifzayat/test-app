import { HeroOrbit } from "../components/HeroOrbit";
import JavascriptIcon from "@/app/assets/icons/square-js.svg";
import HTMLIcon from "@/app/assets/icons/html5.svg";
import CSSIcon from "@/app/assets/icons/css3.svg";
import ReactIcon from "@/app/assets/icons/react.svg";
import ChromeIcon from "@/app/assets/icons/chrome.svg";
import GithubIcon from "@/app/assets/icons/github.svg";
import { TechIcon } from "../components/TechIcon";
import { Card } from "../components/Card";
import { CardHeader } from "../components/CardHeader";
import { ToolBoxItems } from "../components/ToolBoxItems";
const toolboxItems = [
  {
    title: "JavaScript",
    iconType: JavascriptIcon,
  },
  {
    title: "HTML5",
    iconType: HTMLIcon,
  },
  {
    title: "CSS3",
    iconType: CSSIcon,
  },
  {
    title: "React",
    iconType: ReactIcon,
  },
  {
    title: "Chrome",
    iconType: ChromeIcon,
  },
  {
    title: "Github",
    iconType: GithubIcon,
  },
];
export const Skills = () => {
  return (
    <div>
      <HeroOrbit size={250} rotation={-41} shouldOrbit orbitDuration="34s">
        <div className="size-2 rounded-full bg-emerald-300/20" />
      </HeroOrbit>
      <div>
        {toolboxItems.map((item) => (
          <div key={item.title}>
            <TechIcon component={item.iconType} />
            <span>{item.title}</span>
          </div>
        ))}
      </div>
      <CardHeader
        title="skills"
        description="I learn skill by try and error this make me leading fasted I can"
      />
      {/* <ToolBoxItems
        items={toolboxItems}
        className=""
        itemsWrapperClassName="animate-move-lift [animation-duration:30s]"
      /> */}
    </div>
  );
};
